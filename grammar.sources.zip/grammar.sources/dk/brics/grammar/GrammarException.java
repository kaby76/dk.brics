package dk.brics.grammar;

public class GrammarException extends RuntimeException {
   public GrammarException(String var1) {
      super(var1);
   }
}
