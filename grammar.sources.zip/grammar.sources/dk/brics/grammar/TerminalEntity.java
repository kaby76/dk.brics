package dk.brics.grammar;

public abstract class TerminalEntity extends Entity {
   protected TerminalEntity(String var1, String var2) throws GrammarException {
      super(var1, var2);
   }
}
