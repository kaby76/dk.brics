package dk.brics.grammar.ast;

public class LeafNode extends Node {
   private String override;

   public LeafNode(int var1, int var2) {
      super(var1, var2);
   }

   @Override
   public void print(String var1, StringBuilder var2) {
      var2.append(this.getString(var1));
   }

   @Override
   void traverse(NodeVisitor var1) {
      var1.visitLeafNode(this);
   }

   @Override
   public void visitBy(NodeVisitor var1) {
      var1.visitLeafNode(this);
   }

   public void setString(String var1) {
      this.override = var1;
   }

   @Override
   public String getString(String var1) {
      return this.override != null ? this.override : super.getString(var1);
   }
}
