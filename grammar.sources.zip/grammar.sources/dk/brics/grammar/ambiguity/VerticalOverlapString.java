package dk.brics.grammar.ambiguity;

public class VerticalOverlapString {
   private String s;

   public VerticalOverlapString(String var1) {
      this.s = var1;
   }

   public String getString() {
      return this.s;
   }
}
