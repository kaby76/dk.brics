package dk.brics.grammar.main;

import dk.brics.misc.Loader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;

public class MainCommandLine {
   private MainCommandLine() {
   }

   public static void main(String[] var0) {
      String var2;
      String var1 = var2 = Charset.defaultCharset().name();
      boolean var3 = false;
      boolean var4 = false;
      boolean var5 = false;
      boolean var6 = false;
      String var7 = null;
      String var8 = null;
      int var9 = 0;
      String var10 = "";
      String var11 = "";
      boolean var12 = false;
      boolean var13 = false;

      for (int var14 = 0; var14 < var0.length; var14++) {
         String var15 = var0[var14];
         if (var15.startsWith("-")) {
            if (var15.equals("-d")) {
               var3 = true;
            } else if (var15.equals("-a")) {
               var4 = true;
            } else if (var15.equals("-v")) {
               var5 = true;
            } else if (var15.equals("-z")) {
               var6 = true;
            } else if (var15.equals("-h")) {
               var12 = true;
               var13 = true;
            } else if (var15.equals("-g") && var14 + 1 < var0.length) {
               var1 = var0[++var14];
            } else if (var15.equals("-t") && var14 + 1 < var0.length) {
               var2 = var0[++var14];
            } else if (var15.equals("-u") && var14 + 1 < var0.length) {
               try {
                  var9 = Integer.parseInt(var0[++var14]);
               } catch (NumberFormatException var22) {
                  var12 = true;
               }

               if (var9 < 0) {
                  var12 = true;
               }
            } else if (var15.equals("-l") && var14 + 1 < var0.length) {
               var10 = var0[++var14];
            } else if (var15.equals("-r") && var14 + 1 < var0.length) {
               var11 = var0[++var14];
            } else {
               var12 = true;
            }
         } else if (var7 == null) {
            var7 = var15;
         } else if (var8 == null) {
            var8 = var15;
         } else {
            var12 = true;
         }
      }

      if (var7 == null && !var13) {
         var12 = true;
         System.out.println("*** error: no grammar specified");
      }

      if (var12) {
         System.out
            .print(
               "Usage: java dk.brics.grammar.main.Main [Options...] <path or URL of grammar> [ <path or URL of text to parse> ]\n\nThis tool checks whether the given text is syntactically correct according to the\ngiven grammar and that the grammar itself is syntactically correct.\nIt can also check whether the grammar is ambiguous using the technique described in\n\"Analyzing Ambiguity of Context-Free Grammars\", Claus Brabrand, Robert Giegerich,\nand Anders Møller, CIAA 2007.\nIf only a grammar is given, only the grammar checks are performed.\n\nOptions:\n-a                     analyze the grammar for potential ambiguity\n-v                     verbose, print progress information and statistics\n-d                     dump AST in Graphviz dot format after parsing\n-g <encoding>          character encoding used by the grammar\n-t <encoding>          character encoding used by the text\n-u <unfold level>      grammar unfolding level (for ambiguity analysis)\n-l <left parentheses>  left parentheses symbols for grammar unfolding\n-r <right parentheses> right parentheses symbols for grammar unfolding\n-z                     tokenize grammar (for ambiguity analysis)\n\nSystem properties:\n-Ddk.brics.grammar.parser.debug            extra output from parser\n-Ddk.brics.grammar.ambiguity.debug         extra output from ambiguity analyzer\n-Ddk.brics.grammar.ambiguity.noparsecheck  omit parse check in ambiguity analyzer\n-Ddk.brics.grammar.ambiguity.ignorables    force enabling ignorables mode in ambiguity analyzer\n-Ddk.brics.grammar.ambiguity.strategies=[comma separated list of ApproximationStrategy classes]\n"
            );
         System.exit(-1);
      }

      try {
         String var23 = Loader.getString(var7, var1);
         String var24 = var8 != null ? Loader.getString(var8, var2) : null;
         int var16 = Main.run(var23, var7, var24, var8, var4, var9, var10, var11, var5, var3, var6, true, new PrintWriter(System.out, true));
         if (var16 != 0) {
            System.exit(var16);
         }
      } catch (IllegalArgumentException var17) {
         fail(var17);
      } catch (IOException var18) {
         fail(var18);
      } catch (InstantiationException var19) {
         fail(var19);
      } catch (IllegalAccessException var20) {
         fail(var20);
      } catch (ClassNotFoundException var21) {
         fail(var21);
      }
   }

   private static void fail(Exception var0) {
      System.out.println("*** error: " + var0.getMessage());
      System.exit(-1);
   }
}
